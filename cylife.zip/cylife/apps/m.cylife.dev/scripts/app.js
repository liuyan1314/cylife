'use strict';

/**
 * @ngdoc overview
 * @name cylife
 * @description
 * # cylife
 *
 * Main module of the application.
 */
angular
  .module('cylife', [
    'ngAria',
    'ngCookies',
    'ngRoute',
    'cylife.service.auth',
    'cylife.service.product'
  ])
  .config(['$locationProvider', '$routeProvider', '$qProvider', function($locationProvider, $routeProvider, $qProvider) {
    $routeProvider
      .when('/', {
        templateUrl: 'scripts/modules/index/index.html',
        controller: 'IndexController',
        controllerAs: 'index'
      })
      .when('/home', { //首页
        templateUrl: 'scripts/modules/index/home.html',
        controller: 'HomeController',
        controllerAs: 'home'
      })
        .when('/assort', { //商品分类
            templateUrl: 'scripts/modules/list/assort.html',
            controller: 'AssortController',
            controllerAs: 'assort'
        })
        .when('/detail', { //商品详情
            templateUrl: 'scripts/modules/item/detail.html',
            controller: 'DetailController',
            controllerAs: 'detail'
        })
        .when('/shopcar', { //购物车
            templateUrl: 'scripts/modules/cart/shopcar.html',
            controller: 'ShopcarController',
            controllerAs: 'shopcar'
        })
        .when('/list', { //分类专区
            templateUrl: 'scripts/modules/list/list.html',
            controller: 'ListController',
            controllerAs: 'list'
        })
        .when('/self', { //个人中心
            templateUrl: 'scripts/modules/user/self.html',
            controller: 'SelfController',
            controllerAs: 'self'
        })
        .when('/myorder', { //我的订单
            templateUrl: 'scripts/modules/order/myorder.html',
            controller: 'MyorderController',
            controllerAs: 'myorder'
        })
        .when('/selectAddress', { //选择地址
            templateUrl: 'scripts/modules/user/selectAddress.html',
            controller: 'SelectAddressController',
            controllerAs: 'selectAddress'
        })
        .when('/goAddress', { //添加地址
            templateUrl: 'scripts/modules/user/goAddress.html',
            controller: 'GoAddressController',
            controllerAs: 'goAddress'
        })
        .when('/firmorder', { //确认订单
            templateUrl: 'scripts/modules/order/firmorder.html',
            controller: 'FirmorderController',
            controllerAs: 'firmorder'
        })
      .otherwise({
        redirectTo: '/'
      });

     // $qProvider.errorOnUnhandledRejections(false);

  }]);
