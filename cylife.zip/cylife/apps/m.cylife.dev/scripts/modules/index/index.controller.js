

'use strict';

angular
	.module('cylife')
	.controller('IndexController', ['$scope', 'Auth', 'Product', '$http', function ($scope,  Auth, Product, $http) { //作用域必须要一一对应
		// var articles = Acticle.query(function () {
		// 	console.log(articles);
		// });
        //
		// var article = Acticle.get( {nid : 1}, function () {
		// 	console.log(article);
		// } );

        var product= Product.detail({productid:3});

		//console.log(product);

    	//var node = Node.get( {nid : 1, _format:'hal_json'} );
		//console.log(node);

		// console.log('1111');
		//
		// var objNode = new Node;
		// objNode.title = [{'value' : 'add new node'}];
		// objNode.body = [{ "value" :  "my node content" }];
        //
		// Node.save(objNode, function (result) {
		// 	console.log('1111111111111');
		// });

    	/*var loginData = {};
		loginData.name = 'admin';
		loginData.pass = 'admin';*/

		// var user = User.login(loginData);

		// $http({
		// 	method: 'POST',
		// 	url: 'https://user.service.cylife.dev/user/login?_format=json',
		// 	data: {
		// 		"name": "admin", // Change to your real login
		// 		"pass": "admin" // Change to your real password
		// 	},
		// 	headers: {
		// 		'Content-Type': 'application/json'
		// 	}
        //
		// }).then(function successCallback(response) {
		// 	console.log(response);
		// }, function errorCallback(response) {
		// 	// called asynchronously if an error occurs
		// 	// or server returns response with an error status.
		// });

		//var auth = Auth.create(loginData);

		console.log(cy.common.baseEndpoint);
	}]);
