/**
 * Created by liuyan on 2017/1/6.
 */
'use strict';

angular
    .module('cylife')
    .controller('DetailController', ['$scope', 'Auth', 'Product', '$http', function ($scope,  Auth, Product, $http) {


        var product= Product.detail({productid:3});
        //console.log(product);


    }]);
