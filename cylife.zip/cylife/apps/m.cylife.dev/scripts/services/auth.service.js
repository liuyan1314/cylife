/**
 * Created by fengyun on 2016/12/15.
 */

'use strict';

angular
    .module('cylife.service.auth', ['cylife.service'])

    .service('Endpoints', function () {

        var vm = this;
        vm.baseEndpoint = 'https://user.service.cylife.dev/user/login';

        vm.getEndpoint = function (endpoint) {
            if (vm.baseEndpoint == '') {
                return cy.common.baseEndpoint + endpoint;
            } else {
                return vm.baseEndpoint + endpoint;
            }
        }

        return vm;
    })

    .factory('Auth', ['$resource', 'Endpoints', function ($resource, Endpoints) {
        return $resource(Endpoints.baseEndpoint);
    }])