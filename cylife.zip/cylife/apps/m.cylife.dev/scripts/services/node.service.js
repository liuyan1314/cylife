'use strict';
angular
    .module('cylife')
    .factory('Acticle', ['$resource', function ($resource) {
        return $resource('http://admin.cylife.dev/api/articles');
    }])
    .factory('User', ['$resource', function ($resource) {
        return $resource('http://admin.cylife.dev/user/:uid', {uid: '@uid', _format:'json'}, {
            login:{
                method: 'POST',
                url: 'https://user.service.cylife.dev/user/login',
                transformRequest: function (data, headersGetter) {
                    headersGetter()['Content-Type'] = 'application/json';
                    headersGetter()['Accept'] = 'application/json';
                    // var loginData = {};
                    // loginData.name = 'admin';
                    // loginData.pass = 'admin';
                    //
                    //
                    // data = JSON.stringify(loginData);
                    // console.log(data);
                    //headersGetter()['X-CSRF-Token'] =
                    return angular.toJson(data);
                }
            }
        })
    }])
    .factory('Node', ['$resource', function ($resource) {
        var resource = $resource('http://admin.cylife.dev/node/:nid');
        return resource;
    }]);