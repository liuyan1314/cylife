'use strict';

angular
    .module('cylife.service.product', ['cylife.service'])

    .service('Endpoints', function () {

        var vm = this;
        vm.baseEndpoint = 'http://cylife.dev';

        vm.getEndpoint = function (endpoint) {
            if (vm.baseEndpoint == '') {
                return cy.common.baseEndpoint + endpoint;
            } else {
                return vm.baseEndpoint + endpoint;
            }
        };
        vm.product = vm.getEndpoint("/products/:product");
        vm.detail = vm.getEndpoint("/products/detail/:productid");
        //console.log(vm.detail);
        return vm;
    })

    .factory('Product', ['$resource', 'Endpoints', function ($resource, Endpoints) {
        return $resource("http://cylife.dev/products/:product", {product: '@product', _format:'hal_json'}, {
            detail: {
                mothed: 'GET',
                    url: Endpoints.detail,
                transformRequest: function(data, headersGetter){
                    headersGetter()['Content-Type'] = 'application/json';
                    headersGetter()['Accept'] = 'application/json';
                    //console.log(Endpoints.detail);
                   return angular.toJson(data);
                }
            },
        });
    }])



