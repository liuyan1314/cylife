/**
 * Created by fengyun on 2016/12/14.
 */
'use strict';

var cy = angular.module('cylife.service', ['ngResource'])


    .config(['$resourceProvider', function ($resourceProvider) {
           $resourceProvider.defaults.actions = {
                 create: {
                     method: 'POST',
                     params:{_format : cy.common.getFormat()},
                     transformRequest: function (data, headersGetter) {
                         cy.common.setHeaders('POST', headersGetter);
                         return angular.toJson(data);
                     }
                 },
                 get:    {
                     method: 'GET',
                     params:{_format : cy.common.getFormat()},
                 },
                 getAll: {
                     method: 'GET',
                     isArray:true,
                     params:{_format : cy.common.getFormat()},
                 },
                 update: {
                     method: 'PACTH',
                     params:{_format : cy.common.getFormat()},
                     transformRequest: function (data, headersGetter) {
                         cy.common.setHeaders('PACTH', headersGetter);
                         return angular.toJson(data);
                     }
                 },
                 delete: {
                     method: 'DELETE'
                 }
               };

    }]);

cy.common = {

    baseEndpoint  : 'http://api.cylife.dev/v1/',
    mode : 'json',
    getMode: function() {
        return cy.common.mode;
    },
    setMode: function (mode) {
        if (cy.common.getMode() !== mode) {
            if (mode === 'json' || mode === 'hal+json') {
                cy.common.mode = mode;
            }
        }
    },
    getFormat: function() {
        if (cy.common.getMode() == 'json') {
            return 'json';
        }
        else if (cy.common.getMode() == 'hal+json') {
            return 'hal_json';
        }
        else {
            return 'unsupported_format';
        }
    },
    setHeaders: function (method, headersGetter) {

        var addContentType = false;

        if (method === 'POST' || method === 'PATCH') {
            addContentType = true;
        }
        if (cy.common.getMode() === 'hal+json') {
            headersGetter().Accept = 'application/hal+json';
            if (addContentType === true) {
                headersGetter()['Content-Type'] = 'application/hal+json';
            }
        } else if (cy.common.getMode() === 'json') {
            headersGetter().Accept = 'application/json';
            if (addContentType === true) {
                headersGetter()['Content-Type'] = 'application/json';
            }
        }

        // if (DrupalState.get('user').authMethod === 'COOKIE') {
        //     cy.common.addToken(DrupalState, headersGetter);
        // }
        // else if (DrupalState.get('user').authMethod === 'BASIC_AUTH') {
        //     cy.common.addBasicAuth(DrupalState, headersGetter);
        // }

    },

};
